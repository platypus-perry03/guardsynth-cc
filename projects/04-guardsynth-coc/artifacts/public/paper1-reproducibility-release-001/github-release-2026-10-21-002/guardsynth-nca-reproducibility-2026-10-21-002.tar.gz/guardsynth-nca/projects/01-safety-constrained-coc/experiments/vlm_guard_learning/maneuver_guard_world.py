"""Paired-contract micro-world for stopping and lane-change maneuver guards."""

from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal
import re
from typing import Literal

import numpy as np
from PIL import Image, ImageDraw


Maneuver = Literal["cruise_stop", "lane_change"]
Split = Literal["train", "validation", "test", "test_paraphrase", "test_unseen", "test_hard"]
Label = Literal["A", "B", "C", "D"]
LABELS: tuple[Label, ...] = ("A", "B", "C", "D")
MANEUVERS: tuple[Maneuver, ...] = ("cruise_stop", "lane_change")
_CENTIMETRE_PATTERN = re.compile(
    r"(?P<value>\d+(?:\.\d+)?)\s+cm(?P<suffix>/s\^[23])?"
)


@dataclass(frozen=True)
class ManeuverCandidate:
    label: Label
    role: str
    progress: float
    goal_complete: bool
    stop_offset_m: float | None = None
    peak_decel: float | None = None
    peak_jerk: float | None = None
    min_gap_m: float | None = None


@dataclass(frozen=True)
class ManeuverScene:
    scene_id: int
    maneuver: Maneuver
    visual_seed: int
    candidates: tuple[ManeuverCandidate, ...]


@dataclass(frozen=True)
class ManeuverExample:
    scene: ManeuverScene
    contract_level: Literal["permissive", "restrictive"]
    constraint_text: str
    target: Label
    split: Split
    max_decel: float | None = None
    max_jerk: float | None = None
    min_gap: float | None = None


def _fmt(value: float) -> str:
    return f"{value:.1f}"


def normalize_constraint_units(text: str) -> str:
    """Convert centimetre-valued guard bounds to metre-valued text exactly."""

    def replace_centimetres(match: re.Match[str]) -> str:
        metres = Decimal(match.group("value")) / Decimal(100)
        value = format(metres.normalize(), "f")
        return f"{value} m{match.group('suffix') or ''}"

    return _CENTIMETRE_PATTERN.sub(replace_centimetres, text)


def requirement_for(maneuver: Maneuver) -> str:
    return {
        "cruise_stop": "Stop for the pedestrian before the crosswalk, then continue when allowed.",
        "lane_change": "Change to the left lane and continue along the route.",
    }[maneuver]


def make_scene(scene_id: int, seed: int, split: Split, maneuver: Maneuver) -> ManeuverScene:
    rng = np.random.default_rng(seed * 1_000_003 + scene_id * 127)
    unseen = split in {"test_unseen", "test_hard"}
    if maneuver == "cruise_stop":
        hard_decel = float(rng.choice([4.7, 5.0, 5.3] if not unseen else [4.4, 5.6]))
        hard_jerk = float(rng.choice([6.7, 7.0, 7.3] if not unseen else [6.4, 7.6]))
        smooth_decel = float(rng.choice([2.2, 2.5, 2.8] if not unseen else [2.0, 3.0]))
        smooth_jerk = float(rng.choice([2.7, 3.0, 3.3] if not unseen else [2.5, 3.5]))
        physical = [
            ("late_crossing", 110.0, True, 1.0, 2.0, 2.0, None),
            ("hard_stop", 100.0, True, -0.5, hard_decel, hard_jerk, None),
            ("smooth_stop", 85.0, True, -2.0, smooth_decel, smooth_jerk, None),
            ("over_conservative", 35.0, True, -9.0, 1.5, 1.5, None),
        ]
    else:
        early_gap = float(rng.choice([5.7, 6.0, 6.3] if not unseen else [5.4, 6.6]))
        retry_gap = float(rng.choice([11.7, 12.0, 12.3] if not unseen else [11.4, 12.6]))
        physical = [
            ("unsafe_continue", 110.0, True, None, None, None, 2.0),
            ("early_continue", 100.0, True, None, None, None, early_gap),
            ("abort_then_retry", 85.0, True, None, None, None, retry_gap),
            ("abort_deadlock", 0.0, False, None, None, None, None),
        ]
    shift = (scene_id + seed) % 4
    labels = LABELS[shift:] + LABELS[:shift]
    candidates = tuple(
        ManeuverCandidate(label, role, progress, goal, stop, decel, jerk, gap)
        for label, (role, progress, goal, stop, decel, jerk, gap) in zip(labels, physical, strict=True)
    )
    return ManeuverScene(scene_id, maneuver, seed * 100_003 + scene_id * 97, candidates)


def admissible(candidate: ManeuverCandidate, example: ManeuverExample) -> bool:
    if not candidate.goal_complete:
        return True  # A deadlock is non-violating but loses on progress.
    if example.scene.maneuver == "cruise_stop":
        assert candidate.stop_offset_m is not None and candidate.peak_decel is not None and candidate.peak_jerk is not None
        return (
            candidate.stop_offset_m <= 0
            and candidate.peak_decel <= float(example.max_decel) + 1e-9
            and candidate.peak_jerk <= float(example.max_jerk) + 1e-9
        )
    assert candidate.min_gap_m is not None
    return candidate.min_gap_m + 1e-9 >= float(example.min_gap)


def target_for(example: ManeuverExample) -> Label:
    valid = [candidate for candidate in example.scene.candidates if admissible(candidate, example)]
    return max(valid, key=lambda candidate: candidate.progress).label


def _constraint_text(
    maneuver: Maneuver,
    max_decel: float | None,
    max_jerk: float | None,
    min_gap: float | None,
    paraphrase: bool,
) -> str:
    if maneuver == "cruise_stop":
        if paraphrase:
            return (
                "The vehicle must come to rest on the approach side of the stop line while keeping "
                f"peak deceleration no greater than {_fmt(float(max_decel))} m/s^2 and peak jerk no greater than {_fmt(float(max_jerk))} m/s^3."
            )
        return (
            "Stop before the stop line. Peak deceleration must not exceed "
            f"{_fmt(float(max_decel))} m/s^2 and peak jerk must not exceed {_fmt(float(max_jerk))} m/s^3."
        )
    if paraphrase:
        return (
            f"Continue the lane change only while the available gap remains at least {_fmt(float(min_gap))} m; "
            "otherwise abort and retry after the gap recovers."
        )
    return (
        f"Maintain a gap of at least {_fmt(float(min_gap))} m during the lane change. "
        "If the gap drops below this bound, abort and retry only after it is restored."
    )


def generate_maneuver_examples(num_scenes: int, seed: int, split: Split) -> list[ManeuverExample]:
    if num_scenes < 2:
        raise ValueError("num_scenes must be at least two")
    offset = {"train": 0, "validation": 10_000, "test": 20_000, "test_paraphrase": 30_000,
              "test_unseen": 40_000, "test_hard": 50_000}[split]
    examples: list[ManeuverExample] = []
    for local_id in range(num_scenes):
        maneuver = MANEUVERS[local_id % 2]
        scene = make_scene(offset + local_id, seed, split, maneuver)
        hard = next(c for c in scene.candidates if c.role in {"hard_stop", "early_continue"})
        smooth = next(c for c in scene.candidates if c.role in {"smooth_stop", "abort_then_retry"})
        if maneuver == "cruise_stop":
            pairs = (
                ("permissive", float(hard.peak_decel) + 0.5, float(hard.peak_jerk) + 0.7, None),
                ("restrictive", (float(hard.peak_decel) + float(smooth.peak_decel)) / 2,
                 (float(hard.peak_jerk) + float(smooth.peak_jerk)) / 2, None),
            )
        else:
            pairs = (
                ("permissive", None, None, max(0.5, float(hard.min_gap_m) - 0.5)),
                ("restrictive", None, None, (float(hard.min_gap_m) + float(smooth.min_gap_m)) / 2),
            )
        for level, decel, jerk, gap in pairs:
            text = _constraint_text(maneuver, decel, jerk, gap, split == "test_paraphrase")
            provisional = ManeuverExample(scene, level, text, "A", split, decel, jerk, gap)  # type: ignore[arg-type]
            examples.append(replace(provisional, target=target_for(provisional)))
    return examples


def _hard_constraint_text(
    maneuver: Maneuver,
    max_decel: float | None,
    max_jerk: float | None,
    min_gap: float | None,
    style: int,
) -> str:
    """Semantically equivalent constraints with difficult surface forms and units."""
    if maneuver == "cruise_stop":
        decel = float(max_decel)
        jerk = float(max_jerk)
        variants = (
            f"Reject any path that crosses the stop line or has deceleration greater than {_fmt(decel)} m/s^2 "
            f"or jerk greater than {_fmt(jerk)} m/s^3.",
            f"Do not go beyond the stop line. The allowed deceleration ceiling is {_fmt(decel * 100)} cm/s^2 "
            f"and the allowed jerk ceiling is {_fmt(jerk * 100)} cm/s^3.",
            f"A candidate is forbidden if stop offset is positive, peak jerk exceeds {_fmt(jerk)} m/s^3, "
            f"or peak deceleration exceeds {_fmt(decel)} m/s^2; equality is allowed.",
            f"Even if it makes more progress, never select a stop beyond the line. Both |deceleration| <= {_fmt(decel)} m/s^2 "
            f"and |jerk| <= {_fmt(jerk)} m/s^3 must hold.",
        )
        return variants[style % len(variants)]
    gap = float(min_gap)
    variants = (
        f"Reject a lane-change path whenever its minimum gap is below {_fmt(gap)} m; abort first and retry later.",
        f"Never continue through a gap smaller than {_fmt(gap * 100)} cm. Equality with this lower bound is permitted.",
        f"A candidate is forbidden if minimum separation < {_fmt(gap)} m. More route progress does not override this rule.",
        f"Continue only if the gap is no less than {_fmt(gap)} m; otherwise return or abort, then retry after recovery.",
    )
    return variants[style % len(variants)]


def generate_hard_maneuver_examples(num_scenes: int, seed: int) -> list[ManeuverExample]:
    """Boundary-equality pairs using negation, reordered clauses, and unit conversion."""
    if num_scenes < 2:
        raise ValueError("num_scenes must be at least two")
    examples: list[ManeuverExample] = []
    for local_id in range(num_scenes):
        maneuver = MANEUVERS[local_id % 2]
        scene = make_scene(50_000 + local_id, seed, "test_hard", maneuver)
        fast = next(candidate for candidate in scene.candidates if candidate.role in {"hard_stop", "early_continue"})
        cautious = next(candidate for candidate in scene.candidates if candidate.role in {"smooth_stop", "abort_then_retry"})
        if maneuver == "cruise_stop":
            pairs = (
                ("permissive", float(fast.peak_decel), float(fast.peak_jerk), None),
                ("restrictive", (float(fast.peak_decel) + float(cautious.peak_decel)) / 2,
                 (float(fast.peak_jerk) + float(cautious.peak_jerk)) / 2, None),
            )
        else:
            pairs = (
                ("permissive", None, None, float(fast.min_gap_m)),
                ("restrictive", None, None, (float(fast.min_gap_m) + float(cautious.min_gap_m)) / 2),
            )
        for level_index, (level, decel, jerk, gap) in enumerate(pairs):
            text = _hard_constraint_text(maneuver, decel, jerk, gap, local_id + level_index)
            provisional = ManeuverExample(
                scene, level, text, "A", "test_hard", decel, jerk, gap  # type: ignore[arg-type]
            )
            examples.append(replace(provisional, target=target_for(provisional)))
    return examples


def shuffled_constraint_control(examples: list[ManeuverExample], seed: int) -> list[ManeuverExample]:
    """Break the training constraint/target correspondence within each maneuver."""
    rng = np.random.default_rng(seed)
    result: list[ManeuverExample] = []
    for maneuver in MANEUVERS:
        indices = [i for i, example in enumerate(examples) if example.scene.maneuver == maneuver]
        texts = [examples[i].constraint_text for i in indices]
        permutation = np.roll(rng.permutation(len(indices)), 1)
        replacements = {index: texts[int(source)] for index, source in zip(indices, permutation, strict=True)}
        result.extend(replace(examples[index], constraint_text=replacements[index]) for index in indices)
    return sorted(result, key=lambda example: (example.scene.scene_id, example.contract_level != "permissive"))


def candidate_description(candidate: ManeuverCandidate, maneuver: Maneuver) -> str:
    if maneuver == "cruise_stop":
        return (
            f"Candidate {candidate.label}: completes the stop-and-resume goal; stops at {_fmt(float(candidate.stop_offset_m))} m "
            f"relative to the stop line (negative is before); peak deceleration {_fmt(float(candidate.peak_decel))} m/s^2; "
            f"peak jerk {_fmt(float(candidate.peak_jerk))} m/s^3; route progress {_fmt(candidate.progress)} m."
        )
    if not candidate.goal_complete:
        return f"Candidate {candidate.label}: aborts and remains stopped; lane-change goal not completed; route progress 0 m."
    return (
        f"Candidate {candidate.label}: {candidate.role.replace('_', ' ')} and eventually completes the lane change; "
        f"minimum gap {_fmt(float(candidate.min_gap_m))} m; route progress {_fmt(candidate.progress)} m."
    )


def prompt_for(example: ManeuverExample, mode: str) -> str:
    if mode not in {"COC_ONLY", "INLINE_CONSTRAINT"}:
        raise ValueError(f"unknown mode: {mode}")
    requirement = requirement_for(example.scene.maneuver)
    if mode == "INLINE_CONSTRAINT":
        requirement += " " + example.constraint_text
    lines = [f"Requirement CoC: {requirement}"]
    lines.extend(candidate_description(c, example.scene.maneuver) for c in sorted(example.scene.candidates, key=lambda c: c.label))
    lines.append("Select the admissible goal-completing candidate with greatest route progress. Answer exactly A, B, C, or D.")
    return "\n".join(lines)


def render_scene(scene: ManeuverScene, size: int = 224) -> Image.Image:
    image = Image.new("RGB", (size, size), (185, 192, 180))
    draw = ImageDraw.Draw(image)
    road = (67, 71, 74)
    if scene.maneuver == "cruise_stop":
        draw.rectangle((68, 0, 156, size), fill=road)
        draw.line((112, 0, 112, size), fill=(225, 218, 165), width=2)
        draw.line((70, 72, 154, 72), fill=(250, 250, 250), width=5)
        draw.rectangle((103, 160, 121, 196), fill=(38, 122, 220))
        draw.ellipse((82, 51, 90, 59), fill=(245, 205, 165))
        draw.line((86, 58, 86, 72), fill=(145, 35, 150), width=4)
        draw.text((7, 7), "CRUISE -> STOP", fill=(15, 15, 15))
        draw.text((7, 78), "stop line", fill=(15, 15, 15))
    else:
        draw.rectangle((28, 0, 196, size), fill=road)
        draw.line((112, 0, 112, size), fill=(245, 245, 245), width=3)
        draw.rectangle((140, 160, 158, 194), fill=(38, 122, 220))
        draw.rectangle((62, 88, 80, 122), fill=(230, 120, 35))
        draw.rectangle((62, 166, 80, 200), fill=(215, 55, 70))
        draw.line((148, 158, 82, 122), fill=(80, 210, 250), width=4)
        draw.polygon(((82, 122), (91, 123), (86, 131)), fill=(80, 210, 250))
        draw.text((7, 7), "LANE CHANGE: GAP CLOSES", fill=(15, 15, 15))
    return image
