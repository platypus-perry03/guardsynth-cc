"""Counterfactual candidate-trajectory world for explicit safety-guard learning."""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Literal

import numpy as np
from PIL import Image, ImageDraw


ConstraintKind = Literal["max_speed", "min_clearance", "min_entry_delay"]
Split = Literal["train", "validation", "test", "test_paraphrase", "test_unseen"]
CONSTRAINT_KINDS: tuple[ConstraintKind, ...] = (
    "max_speed",
    "min_clearance",
    "min_entry_delay",
)
COC_TEXT = "Proceed through the intersection and continue along the route."


@dataclass(frozen=True)
class Candidate:
    name: Literal["A", "B"]
    speed: float
    clearance: float
    entry_delay: float
    progress: float
    cautious: bool


@dataclass(frozen=True)
class CandidateScene:
    scene_id: int
    visual_seed: int
    candidate_a: Candidate
    candidate_b: Candidate


@dataclass(frozen=True)
class CandidateGuardExample:
    scene: CandidateScene
    constraint_kind: ConstraintKind
    threshold: float
    contract_level: Literal["restrictive", "permissive"]
    guard_text: str
    rich_coc_text: str
    logic_guard_text: str
    target: Literal["A", "B"]
    violating_candidate: Literal["A", "B", "NONE"]
    split: Split


def _fmt(value: float) -> str:
    return f"{value:.1f}"


def _guard_text(kind: ConstraintKind, threshold: float, paraphrase: bool) -> str:
    value = _fmt(threshold)
    if paraphrase:
        return {
            "max_speed": f"The trajectory must keep peak velocity at or below {value} m/s.",
            "min_clearance": f"The trajectory must preserve no less than {value} m of obstacle clearance.",
            "min_entry_delay": f"The trajectory must wait at least {value} s before entering the intersection.",
        }[kind]
    return {
        "max_speed": f"Maximum speed must not exceed {value} m/s.",
        "min_clearance": f"Minimum obstacle clearance must be at least {value} m.",
        "min_entry_delay": f"Intersection entry time must be no earlier than {value} s from now.",
    }[kind]


def _rich_coc(kind: ConstraintKind, threshold: float, paraphrase: bool) -> str:
    return COC_TEXT + " " + _guard_text(kind, threshold, paraphrase)


def _logic_guard(kind: ConstraintKind, threshold: float) -> str:
    op = "<=" if kind == "max_speed" else ">="
    field = {
        "max_speed": "trajectory.max_speed_mps",
        "min_clearance": "trajectory.min_clearance_m",
        "min_entry_delay": "trajectory.entry_delay_s",
    }[kind]
    return f"ASSERT {field} {op} {_fmt(threshold)}"


def satisfies(candidate: Candidate, kind: ConstraintKind, threshold: float) -> bool:
    if kind == "max_speed":
        return candidate.speed <= threshold + 1e-9
    if kind == "min_clearance":
        return candidate.clearance + 1e-9 >= threshold
    return candidate.entry_delay + 1e-9 >= threshold


def preferred_admissible(scene: CandidateScene, kind: ConstraintKind, threshold: float) -> str:
    candidates = [scene.candidate_a, scene.candidate_b]
    admissible = [candidate for candidate in candidates if satisfies(candidate, kind, threshold)]
    if not admissible:
        raise ValueError("every generated contract must retain an admissible candidate")
    return max(admissible, key=lambda candidate: candidate.progress).name


def make_scene(scene_id: int, seed: int, split: Split) -> CandidateScene:
    rng = np.random.default_rng(seed * 1_000_003 + scene_id * 101)
    if split == "test_unseen":
        fast_speed = float(rng.choice([5.5, 6.5]))
        slow_speed = float(rng.choice([2.5, 3.5]))
        fast_clearance = float(rng.choice([0.8, 1.4]))
        slow_clearance = float(rng.choice([2.6, 3.4]))
        fast_delay = float(rng.choice([0.8, 1.4]))
        slow_delay = float(rng.choice([3.6, 4.4]))
    else:
        fast_speed = float(rng.choice([5.8, 6.0, 6.2]))
        slow_speed = float(rng.choice([2.8, 3.0, 3.2]))
        fast_clearance = float(rng.choice([0.9, 1.0, 1.1]))
        slow_clearance = float(rng.choice([2.9, 3.0, 3.1]))
        fast_delay = float(rng.choice([0.9, 1.0, 1.1]))
        slow_delay = float(rng.choice([3.9, 4.0, 4.1]))
    fast = Candidate("A", fast_speed, fast_clearance, fast_delay, 100.0, False)
    cautious = Candidate("B", slow_speed, slow_clearance, slow_delay, 75.0, True)
    # Prevent the model from equating the physical trajectory with a fixed answer token.
    if (scene_id + seed) % 2:
        fast = replace(fast, name="B")
        cautious = replace(cautious, name="A")
    by_name = {fast.name: fast, cautious.name: cautious}
    return CandidateScene(scene_id, seed * 100_003 + scene_id * 97, by_name["A"], by_name["B"])


def _thresholds(scene: CandidateScene, kind: ConstraintKind, unseen: bool) -> tuple[float, float]:
    fast = next(c for c in (scene.candidate_a, scene.candidate_b) if not c.cautious)
    cautious = next(c for c in (scene.candidate_a, scene.candidate_b) if c.cautious)
    if kind == "max_speed":
        restrictive = (fast.speed + cautious.speed) / 2
        permissive = fast.speed + (1.3 if unseen else 1.0)
    elif kind == "min_clearance":
        restrictive = (fast.clearance + cautious.clearance) / 2
        permissive = max(0.2, fast.clearance - (0.3 if unseen else 0.5))
    else:
        restrictive = (fast.entry_delay + cautious.entry_delay) / 2
        permissive = max(0.2, fast.entry_delay - (0.3 if unseen else 0.5))
    return round(restrictive, 1), round(permissive, 1)


def generate_candidate_examples(
    num_scenes: int, seed: int, split: Split
) -> list[CandidateGuardExample]:
    if num_scenes < 1:
        raise ValueError("num_scenes must be positive")
    offset = {
        "train": 0,
        "validation": 10_000,
        "test": 20_000,
        "test_paraphrase": 30_000,
        "test_unseen": 40_000,
    }[split]
    examples: list[CandidateGuardExample] = []
    for local_id in range(num_scenes):
        scene = make_scene(offset + local_id, seed, split)
        for kind in CONSTRAINT_KINDS:
            restrictive, permissive = _thresholds(scene, kind, split == "test_unseen")
            for level, threshold in (("restrictive", restrictive), ("permissive", permissive)):
                target = preferred_admissible(scene, kind, threshold)
                violating = [
                    candidate.name
                    for candidate in (scene.candidate_a, scene.candidate_b)
                    if not satisfies(candidate, kind, threshold)
                ]
                examples.append(
                    CandidateGuardExample(
                        scene=scene,
                        constraint_kind=kind,
                        threshold=threshold,
                        contract_level=level,
                        guard_text=_guard_text(kind, threshold, split == "test_paraphrase"),
                        rich_coc_text=_rich_coc(kind, threshold, split == "test_paraphrase"),
                        logic_guard_text=_logic_guard(kind, threshold),
                        target=target,
                        violating_candidate=violating[0] if violating else "NONE",
                        split=split,
                    )
                )
    return examples


def shuffled_guard_control(
    examples: list[CandidateGuardExample], seed: int
) -> list[CandidateGuardExample]:
    """Swap contract texts across examples without changing scenes or targets."""
    rng = np.random.default_rng(seed)
    texts = [(e.guard_text, e.logic_guard_text, e.rich_coc_text) for e in examples]
    permutation = rng.permutation(len(examples))
    # A derangement is unnecessary, but avoid accidental identity entries deterministically.
    permutation = np.roll(permutation, 1)
    return [
        replace(
            example,
            guard_text=texts[int(source)][0],
            logic_guard_text=texts[int(source)][1],
            rich_coc_text=texts[int(source)][2],
        )
        for example, source in zip(examples, permutation, strict=True)
    ]


def candidate_description(candidate: Candidate) -> str:
    return (
        f"Candidate {candidate.name}: completes the route; maximum speed {_fmt(candidate.speed)} m/s; "
        f"minimum obstacle clearance {_fmt(candidate.clearance)} m; intersection entry at "
        f"{_fmt(candidate.entry_delay)} s; route progress {_fmt(candidate.progress)} m."
    )


def prompt_for(example: CandidateGuardExample, mode: str) -> str:
    if mode not in {"COC_ONLY", "RICH_COC", "NATURAL_GUARD", "LOGIC_GUARD"}:
        raise ValueError(f"unknown prompt mode: {mode}")
    coc = example.rich_coc_text if mode == "RICH_COC" else COC_TEXT
    lines = [f"Requirement CoC: {coc}"]
    if mode == "NATURAL_GUARD":
        lines.append(f"Safety guard: {example.guard_text}")
    elif mode == "LOGIC_GUARD":
        lines.append(f"Safety guard: {example.logic_guard_text}")
    lines.extend(
        [
            candidate_description(example.scene.candidate_a),
            candidate_description(example.scene.candidate_b),
            "Both candidates complete the CoC goal. Select the admissible candidate with greater route progress. Answer exactly A or B.",
        ]
    )
    return "\n".join(lines)


def render_candidate_scene(scene: CandidateScene, size: int = 224) -> Image.Image:
    image = Image.new("RGB", (size, size), (185, 191, 180))
    draw = ImageDraw.Draw(image)
    center = size // 2
    half = int(size * 0.26)
    road = (65, 69, 72)
    draw.rectangle((center - half, 0, center + half, size), fill=road)
    draw.rectangle((0, center - half, size, center + half), fill=road)
    draw.line((center, 0, center, size), fill=(220, 215, 170), width=2)
    draw.line((0, center, size, center), fill=(220, 215, 170), width=2)
    # An obstacle makes clearance geometrically meaningful.
    draw.rectangle((center + 13, center - 15, center + 32, center + 8), fill=(222, 126, 43))
    # The two complete candidate paths differ in clearance; prompt text supplies exact values.
    colors = {"A": (40, 150, 235), "B": (220, 55, 85)}
    for candidate in (scene.candidate_a, scene.candidate_b):
        lateral = int(candidate.clearance * 10)
        x = center - lateral
        points = [(center, size - 12), (x, center + 30), (x, center - 30), (center, 12)]
        draw.line(points, fill=colors[candidate.name], width=5)
        draw.text((x - 5, center - 46), candidate.name, fill=colors[candidate.name])
    draw.text((6, 6), "A/B candidate trajectories", fill=(15, 15, 15))
    return image
