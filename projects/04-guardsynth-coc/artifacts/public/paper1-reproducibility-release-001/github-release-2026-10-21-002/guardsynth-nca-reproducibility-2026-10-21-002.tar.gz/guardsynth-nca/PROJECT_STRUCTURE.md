# Frozen GuardSynth NCA distribution

Owner: guardsynth-coc. Retains original project/platform paths. See README.md.
