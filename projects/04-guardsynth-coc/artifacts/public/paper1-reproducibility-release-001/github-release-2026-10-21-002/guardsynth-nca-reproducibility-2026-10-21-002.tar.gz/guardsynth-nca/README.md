# GuardSynth NCA reproducibility distribution

Owner: `guardsynth-coc`. This frozen source/data distribution accompanies the
NCA manuscript on checked behavioral constraints for CoC-augmented candidate
selection. It preserves project-relative paths and removes host-specific metadata
from exported copies. Original experiment records in the working repository are unchanged.

## Quick verification (Python 3.11, standard library only)

Extract the archive into an empty directory and run from its root:

```sh
python3 projects/04-guardsynth-coc/pipelines/cli/paper_release/verify.py --root .
```

This verifies every manifest SHA-256 and independently recomputes admissibility,
preferred candidates, preferred-selection scores, violation rates and rule-pair
scores from the fresh-adapter and pretrained 2B/8B prediction records. The
historical field `accuracy` means preferred-selection score. Invalid responses
are incorrect and count as neither violations nor admissible choices.
The main 12-token pretrained runs and post-hoc generation-budget records are
kept separate. For example, 2B's 0% violation rate with all invalid answers is
not evidence of compliance.

## Included evidence

- Frozen train/test JSONL, synthetic images, protocols, per-seed predictions,
  and records for the four fresh-adapter conditions and pretrained VLM controls.
- Six-task and position-hold continuation datasets and prediction records,
  paraphrase/unseen-value diagnostics, and the earlier expression-diversity checks.
- Learning-specification fault injection: 384 cases, including 288 supported
  faults, 48 valid controls and 48 jointly wrong source/specification cases.
- Document-grounded authored composition: 176 cases (58 UNSAT, 118 SAT),
  including 12 three-way conflicts with satisfiable pairs. These are authored
  restricted models, not reconstructions or safety certifications of vehicles.
- Selected maintained source dependencies, unchanged Core/SMT implementation,
  schema, solver build provenance, and unit tests.

`SOURCE_MANIFEST.json` is the authority for exactly which files are included,
their public hashes, original-file hashes, relative paths and licenses. Exported
run manifests may reference omitted weights, logs and earlier code versions.
Historical embedded digests remain provenance records; the source manifest is
the authority for hashes of the sanitized distribution. The exported source is the release-time
snapshot, not a claim that every historical source hash matches today's source.
Historical shuffled-rule controls are retained only where embedded in original
aggregate records; they are not a current manuscript claim.

## Rerun the formal checks

The recorded solver is Z3 **5.0.0**, not a generic pip 4.x solver. Build the
upstream `z3-5.0.0` release with Python bindings into the prefix recorded in
`runtime/solvers/z3-5.0.0-x86_64-glibc-2.36/INSTALL_MANIFEST.json`, or set
`GUARDSYNTH_Z3_PREFIX` to an equivalent installation. Its archive hash and GCC12
compatibility-header provenance are included. Solver binaries are excluded.
Install the lightweight dependencies with `python3 -m pip install -r requirements-checks.txt`.
The release's formal rerun was tested with Python 3.12.13, NumPy 2.2.6,
Pillow 12.1.1 and the recorded Z3 build. Then run:

```sh
python3 -m unittest discover -s projects/04-guardsynth-coc/tests -p test_learning_specification_faults.py
python3 -m unittest discover -s projects/04-guardsynth-coc/tests/unit -p 'test_*composition.py'
python3 projects/04-guardsynth-coc/experiments/paper1_cnl_learning/learning_specification_faults.py --run-id learning-specification-faults-reproduction-001
python3 projects/04-guardsynth-coc/experiments/paper1_cnl_learning/document_grounded_composition.py --run-id document-grounded-composition-reproduction-001
```

The runners refuse to overwrite existing runs. Compare the new `RESULT.json`
aggregates to the archived ones. Unit tests are controls; the full runners
exercise all archived-profile cases. The standard-library verifier reads
checker aggregate records; it does not itself execute SMT.

## GPU learning and inference

`run_vlm_constraint_baselines.py --help` documents prepare, fit, pretrained,
and aggregate actions. A new run ID is required. There are 2 tasks × 4 arms ×
3 seeds = 24 fits, with identical initial LoRA tensors per task/seed.
The code expects local model snapshots; download official Hugging Face models:

- `Qwen/Qwen3-VL-2B-Instruct`, revision
  `89644892e4d85e24eaac8bacfd4f463576704203`, at the normal HF cache path.
- `Qwen/Qwen3-VL-8B-Instruct`, revision
  `0c351dd01ed87e9c1b53cbc748cba10e6187ff3b`, under the recorded
  `runtime/alpamayo/hf_cache/` snapshot path (or adjust the local model constant).

The available local GPU environment at release time has PyTorch 2.8.0,
Transformers 4.57.1, PEFT 0.20.0 and Matplotlib 3.10.8. These are recorded
for setup guidance, not a new GPU training validation or a complete historical lockfile.
Training scripts preserve their recorded path assumptions.
They are provided for inspection and reproduction; the release validation
does not rerun 24 GPU fits or assert bitwise GPU determinism. Per-run training
metadata records budgets and initialization hashes. Adapter/model weights are excluded.
The selected source supports the fresh-adapter experiments and formal checks;
older six-task/continuation predictions and datasets are included as evidence,
not a promise that every historical launch/scheduler workflow is exported.

## License and boundaries

Original code: **MIT**, `license-code.txt`. Synthetic data and generated
experiment records: **CC BY 4.0**, `license-data.txt`. Third-party references
and dependencies retain their own licenses; the accompanying solver build
manifest and compatibility shim are build provenance, not a Z3 redistribution.
Minimal registry markers and only migration hashes for the exported files are
included for path resolution; the full repository governance catalog is excluded.
These markers are not relicensed as synthetic data. This release grants no blanket license to other
files in the parent monorepo.

Excluded: licensed road imagery/raw Alpamayo inputs, model/adapter weights,
private expert-review submissions, credentials, API-server state and logs,
and unrelated projects/apps. Obtaining original restricted road inputs requires
the original providers' access terms; the Alpamayo diagnostics cannot be
reproduced from this synthetic-data distribution alone.
