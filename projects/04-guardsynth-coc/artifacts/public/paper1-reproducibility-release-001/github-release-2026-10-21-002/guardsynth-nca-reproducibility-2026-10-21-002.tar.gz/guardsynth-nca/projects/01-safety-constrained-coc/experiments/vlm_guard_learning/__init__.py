"""Small-VLM guard-compliance learning experiments."""
