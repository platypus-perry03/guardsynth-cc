#!/usr/bin/env python3
"""Train a small Qwen3-VL LoRA to select guard-compliant trajectory prototypes."""

from __future__ import annotations

import argparse
import json
import random
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch
from peft import LoraConfig, TaskType, get_peft_model
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader, Dataset
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

from .guard_world import (
    GuardExample,
    generate_examples,
    prompt_for,
    render_scene,
    shuffled_guard_control,
)


MODEL_ID = "Qwen/Qwen3-VL-2B-Instruct"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--condition",
        choices=(
            "COC_ONLY",
            "GUARD",
            "SHUFFLED_GUARD",
            "TRADITIONAL_COC",
            "COC_GUARD",
        ),
        required=True,
    )
    parser.add_argument("--model-id", default=MODEL_ID)
    parser.add_argument("--train-scenes", type=int, default=192)
    parser.add_argument("--validation-scenes", type=int, default=32)
    parser.add_argument("--test-scenes", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--gradient-accumulation", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--lora-rank", type=int, default=8)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--max-eval-examples", type=int, default=192)
    return parser.parse_args()


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class ExampleDataset(Dataset[GuardExample]):
    def __init__(self, examples: list[GuardExample]):
        self.examples = examples

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, index: int) -> GuardExample:
        return self.examples[index]


class MultimodalCollator:
    def __init__(self, processor: Any, prompt_mode: str):
        self.processor = processor
        self.prompt_mode = prompt_mode
        self.pad_id = int(processor.tokenizer.pad_token_id)

    @staticmethod
    def user_message(example: GuardExample, prompt_mode: str) -> dict[str, Any]:
        return {
            "role": "user",
            "content": [
                {"type": "image", "image": render_scene(example.scene)},
                {"type": "text", "text": prompt_for(example, prompt_mode)},
            ],
        }

    def _encode(self, example: GuardExample) -> dict[str, torch.Tensor]:
        user = self.user_message(example, self.prompt_mode)
        prompt = self.processor.apply_chat_template(
            [user],
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        )
        full = self.processor.apply_chat_template(
            [user, {"role": "assistant", "content": [{"type": "text", "text": example.target}]}],
            tokenize=True,
            add_generation_prompt=False,
            return_dict=True,
            return_tensors="pt",
        )
        labels = full["input_ids"][0].clone()
        labels[: prompt["input_ids"].shape[1]] = -100
        return {
            "input_ids": full["input_ids"][0],
            "attention_mask": full["attention_mask"][0],
            "labels": labels,
            "pixel_values": full["pixel_values"],
            "image_grid_thw": full["image_grid_thw"],
        }

    def __call__(self, examples: list[GuardExample]) -> dict[str, torch.Tensor]:
        encoded = [self._encode(example) for example in examples]
        return {
            "input_ids": pad_sequence(
                [item["input_ids"] for item in encoded], batch_first=True, padding_value=self.pad_id
            ),
            "attention_mask": pad_sequence(
                [item["attention_mask"] for item in encoded], batch_first=True, padding_value=0
            ),
            "labels": pad_sequence(
                [item["labels"] for item in encoded], batch_first=True, padding_value=-100
            ),
            "pixel_values": torch.cat([item["pixel_values"] for item in encoded], dim=0),
            "image_grid_thw": torch.cat([item["image_grid_thw"] for item in encoded], dim=0),
        }


def to_device(batch: dict[str, torch.Tensor], device: str) -> dict[str, torch.Tensor]:
    return {key: value.to(device, non_blocking=True) for key, value in batch.items()}


def parse_choice(text: str) -> str:
    normalized = text.strip().upper()
    stop_pos = normalized.find("STOP")
    proceed_pos = normalized.find("PROCEED")
    if stop_pos < 0 and proceed_pos < 0:
        return "INVALID"
    if stop_pos >= 0 and (proceed_pos < 0 or stop_pos < proceed_pos):
        return "STOP"
    return "PROCEED"


def generate_choice(
    model: Any,
    processor: Any,
    example: GuardExample,
    prompt_mode: str,
    device: str,
) -> tuple[str, str]:
    user = MultimodalCollator.user_message(example, prompt_mode)
    encoded = processor.apply_chat_template(
        [user],
        tokenize=True,
        add_generation_prompt=True,
        return_dict=True,
        return_tensors="pt",
    )
    encoded = to_device(dict(encoded), device)
    prompt_length = encoded["input_ids"].shape[1]
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        output = model.generate(
            **encoded,
            do_sample=False,
            max_new_tokens=5,
            use_cache=True,
            pad_token_id=processor.tokenizer.pad_token_id,
        )
    text = processor.tokenizer.decode(output[0, prompt_length:], skip_special_tokens=True)
    return parse_choice(text), text.strip()


def evaluate(
    model: Any,
    processor: Any,
    examples: list[GuardExample],
    prompt_mode: str,
    device: str,
    max_examples: int,
) -> dict[str, Any]:
    selected = examples[:max_examples]
    rows: list[dict[str, Any]] = []
    model.eval()
    for example in selected:
        prediction, raw = generate_choice(model, processor, example, prompt_mode, device)
        rows.append(
            {
                "scene_id": example.scene.scene_id,
                "guard_kind": example.guard_kind,
                "target": example.target,
                "prediction": prediction,
                "raw": raw,
                "correct": prediction == example.target,
            }
        )
    by_guard: dict[str, list[bool]] = defaultdict(list)
    by_target: dict[str, list[bool]] = defaultdict(list)
    for row in rows:
        by_guard[row["guard_kind"]].append(row["correct"])
        by_target[row["target"]].append(row["correct"])
    scene_rows: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        scene_rows[row["scene_id"]].append(row)
    informative_scenes = [
        group for group in scene_rows.values() if len({row["target"] for row in group}) > 1
    ]
    fully_correct_counterfactual = sum(all(row["correct"] for row in group) for group in informative_scenes)
    return {
        "example_count": len(rows),
        "accuracy": sum(row["correct"] for row in rows) / len(rows),
        "invalid_rate": sum(row["prediction"] == "INVALID" for row in rows) / len(rows),
        "stop_prediction_rate": sum(row["prediction"] == "STOP" for row in rows) / len(rows),
        "accuracy_by_guard": {
            guard: sum(values) / len(values) for guard, values in sorted(by_guard.items())
        },
        "accuracy_by_target": {
            target: sum(values) / len(values) for target, values in sorted(by_target.items())
        },
        "informative_scene_count": len(informative_scenes),
        "fully_correct_counterfactual_scene_rate": (
            fully_correct_counterfactual / len(informative_scenes) if informative_scenes else None
        ),
        "rows": rows,
    }


def language_attention_targets(model: Any) -> list[str]:
    targets = [
        name
        for name, module in model.named_modules()
        if isinstance(module, torch.nn.Linear)
        and "language_model" in name
        and name.rsplit(".", 1)[-1] in {"q_proj", "k_proj", "v_proj", "o_proj"}
    ]
    if not targets:
        raise RuntimeError("no Qwen language attention projection modules were found")
    return targets


def train(
    model: Any,
    processor: Any,
    examples: list[GuardExample],
    prompt_mode: str,
    args: argparse.Namespace,
) -> list[dict[str, float]]:
    collator = MultimodalCollator(processor, prompt_mode)
    generator = torch.Generator().manual_seed(args.seed + 1000)
    loader = DataLoader(
        ExampleDataset(examples),
        batch_size=args.batch_size,
        shuffle=True,
        generator=generator,
        num_workers=0,
        collate_fn=collator,
    )
    optimizer = torch.optim.AdamW(
        [parameter for parameter in model.parameters() if parameter.requires_grad],
        lr=args.learning_rate,
        weight_decay=0.01,
    )
    history: list[dict[str, float]] = []
    model.train()
    optimizer.zero_grad(set_to_none=True)
    for epoch in range(args.epochs):
        running_loss = 0.0
        example_count = 0
        optimizer_steps = 0
        for batch_index, batch in enumerate(loader):
            batch = to_device(batch, args.device)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                output = model(**batch, use_cache=False)
                loss = output.loss / args.gradient_accumulation
            loss.backward()
            batch_examples = int(batch["input_ids"].shape[0])
            running_loss += float(loss.detach()) * args.gradient_accumulation * batch_examples
            example_count += batch_examples
            last_batch = batch_index + 1 == len(loader)
            if (batch_index + 1) % args.gradient_accumulation == 0 or last_batch:
                torch.nn.utils.clip_grad_norm_(
                    [parameter for parameter in model.parameters() if parameter.requires_grad], 1.0
                )
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
                optimizer_steps += 1
        history.append(
            {
                "epoch": float(epoch + 1),
                "mean_loss": running_loss / example_count,
                "optimizer_steps": float(optimizer_steps),
            }
        )
    return history


def main() -> int:
    args = parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    args.output_dir.mkdir(parents=True, exist_ok=False, mode=0o700)
    args.output_dir.chmod(0o700)
    seed_all(args.seed)
    prompt_modes = {
        "COC_ONLY": "GENERIC_COC",
        "GUARD": "GENERIC_COC_GUARD",
        "SHUFFLED_GUARD": "GENERIC_COC_GUARD",
        "TRADITIONAL_COC": "TRADITIONAL_COC",
        "COC_GUARD": "TRADITIONAL_COC_GUARD",
    }
    prompt_mode = prompt_modes[args.condition]

    processor = AutoProcessor.from_pretrained(args.model_id)
    processor.tokenizer.padding_side = "right"
    model = Qwen3VLForConditionalGeneration.from_pretrained(
        args.model_id,
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
    ).to(args.device)
    model.config.use_cache = False

    targets = language_attention_targets(model)
    lora_config = LoraConfig(
        r=args.lora_rank,
        lora_alpha=args.lora_rank * 2,
        lora_dropout=0.05,
        bias="none",
        task_type=TaskType.CAUSAL_LM,
        target_modules=targets,
    )
    model = get_peft_model(model, lora_config)
    model.enable_input_require_grads()
    trainable = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
    total = sum(parameter.numel() for parameter in model.parameters())

    train_examples = generate_examples(args.train_scenes, args.seed, "train")
    if args.condition == "SHUFFLED_GUARD":
        train_examples = shuffled_guard_control(train_examples, args.seed + 77_777)
    validation_examples = generate_examples(args.validation_scenes, args.seed, "validation")
    test_examples = generate_examples(args.test_scenes, args.seed, "test")
    paraphrase_examples = generate_examples(args.test_scenes, args.seed, "test_paraphrase")

    # A short pre-training baseline uses the same prompt condition and evaluation subset.
    pre_validation = evaluate(
        model,
        processor,
        validation_examples,
        prompt_mode,
        args.device,
        min(args.max_eval_examples, len(validation_examples)),
    )
    history = train(model, processor, train_examples, prompt_mode, args)
    post_validation = evaluate(
        model,
        processor,
        validation_examples,
        prompt_mode,
        args.device,
        min(args.max_eval_examples, len(validation_examples)),
    )
    post_test = evaluate(
        model,
        processor,
        test_examples,
        prompt_mode,
        args.device,
        min(args.max_eval_examples, len(test_examples)),
    )
    post_paraphrase = evaluate(
        model,
        processor,
        paraphrase_examples,
        prompt_mode,
        args.device,
        min(args.max_eval_examples, len(paraphrase_examples)),
    )

    adapter_dir = args.output_dir / "adapter"
    model.save_pretrained(adapter_dir)
    processor.save_pretrained(args.output_dir / "processor")
    result = {
        "experiment_id": "SMALL-VLM-GUARD-LEARNING-V0",
        "created_at_utc": now_utc(),
        "condition": args.condition,
        "prompt_mode": prompt_mode,
        "model_id": args.model_id,
        "seed": args.seed,
        "train_scenes": args.train_scenes,
        "train_examples": len(train_examples),
        "validation_scenes": args.validation_scenes,
        "test_scenes": args.test_scenes,
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "gradient_accumulation": args.gradient_accumulation,
        "learning_rate": args.learning_rate,
        "lora_rank": args.lora_rank,
        "trainable_parameters": trainable,
        "total_parameters": total,
        "trainable_fraction": trainable / total,
        "lora_target_module_count": len(targets),
        "history": history,
        "pre_validation": pre_validation,
        "post_validation": post_validation,
        "post_test": post_test,
        "post_paraphrase": post_paraphrase,
    }
    result_path = args.output_dir / "result.json"
    result_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
