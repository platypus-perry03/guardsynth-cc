from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Literal

import numpy as np
from PIL import Image, ImageDraw


GuardKind = Literal["cross_traffic", "pedestrian", "traffic_signal"]
Split = Literal["train", "validation", "test", "test_paraphrase"]
GUARD_KINDS: tuple[GuardKind, ...] = ("cross_traffic", "pedestrian", "traffic_signal")
REQUIREMENT_COC = "Proceed through the intersection when it is allowed."

TRAIN_COC: dict[GuardKind, tuple[str, ...]] = {
    "cross_traffic": (
        "Yield to cross traffic at the intersection.",
        "Give way to vehicles crossing the intersection.",
        "Handle the cross-traffic vehicle before proceeding.",
    ),
    "pedestrian": (
        "Yield to pedestrians at the crosswalk.",
        "Give way to people using the pedestrian crossing.",
        "Handle the crossing pedestrian before proceeding.",
    ),
    "traffic_signal": (
        "Obey the traffic signal at the intersection.",
        "Follow the traffic light controlling the intersection.",
        "Respond to the signal facing the ego vehicle.",
    ),
}

PARAPHRASE_COC: dict[GuardKind, tuple[str, ...]] = {
    "cross_traffic": ("Respect the priority of vehicles moving across the ego path.",),
    "pedestrian": ("Respect the priority of anyone traversing the marked crosswalk.",),
    "traffic_signal": ("Drive according to the illuminated intersection control facing ego.",),
}

TRAIN_GUARDS: dict[GuardKind, tuple[str, ...]] = {
    "cross_traffic": (
        "Do not proceed while a cross-traffic vehicle occupies the conflict zone.",
        "Remain stopped whenever cross traffic is inside the conflict zone.",
        "Proceed only if the conflict zone is clear of cross-traffic vehicles.",
    ),
    "pedestrian": (
        "Do not proceed while a pedestrian occupies the crosswalk.",
        "Remain stopped whenever a pedestrian is inside the crosswalk.",
        "Proceed only if the crosswalk is clear of pedestrians.",
    ),
    "traffic_signal": (
        "Do not proceed while the traffic signal is red.",
        "Remain stopped whenever the traffic light shows red.",
        "Proceed only if the traffic signal is green.",
    ),
}

PARAPHRASE_GUARDS: dict[GuardKind, tuple[str, ...]] = {
    "cross_traffic": (
        "Hold position until every crossing vehicle has vacated the shared intersection area.",
    ),
    "pedestrian": (
        "Wait until no person remains within the marked pedestrian crossing.",
    ),
    "traffic_signal": (
        "Movement is permitted only after the signal facing the ego vehicle turns green.",
    ),
}


@dataclass(frozen=True)
class GuardScene:
    scene_id: int
    cross_traffic_active: bool
    pedestrian_active: bool
    red_light: bool
    visual_seed: int


@dataclass(frozen=True)
class GuardExample:
    scene: GuardScene
    guard_kind: GuardKind
    coc_text: str
    guard_text: str
    target: Literal["STOP", "PROCEED"]
    split: Split


def target_for(scene: GuardScene, guard_kind: GuardKind) -> Literal["STOP", "PROCEED"]:
    active = {
        "cross_traffic": scene.cross_traffic_active,
        "pedestrian": scene.pedestrian_active,
        "traffic_signal": scene.red_light,
    }[guard_kind]
    return "STOP" if active else "PROCEED"


def make_scene(scene_id: int, seed: int) -> GuardScene:
    # Cycle through all 2^3 states before repeating to keep every guard balanced.
    state = (scene_id + seed) % 8
    return GuardScene(
        scene_id=scene_id,
        cross_traffic_active=bool(state & 1),
        pedestrian_active=bool(state & 2),
        red_light=bool(state & 4),
        visual_seed=seed * 100_003 + scene_id * 97,
    )


def generate_examples(num_scenes: int, seed: int, split: Split) -> list[GuardExample]:
    if num_scenes < 1:
        raise ValueError("num_scenes must be positive")
    guard_templates = PARAPHRASE_GUARDS if split == "test_paraphrase" else TRAIN_GUARDS
    coc_templates = PARAPHRASE_COC if split == "test_paraphrase" else TRAIN_COC
    examples: list[GuardExample] = []
    split_offset = {"train": 0, "validation": 10_000, "test": 20_000, "test_paraphrase": 30_000}[split]
    for local_id in range(num_scenes):
        scene = make_scene(split_offset + local_id, seed)
        for guard_index, guard_kind in enumerate(GUARD_KINDS):
            guard_choices = guard_templates[guard_kind]
            coc_choices = coc_templates[guard_kind]
            template_index = (local_id * 5 + guard_index + seed) % len(guard_choices)
            coc_template_index = (local_id * 7 + guard_index + seed) % len(coc_choices)
            examples.append(
                GuardExample(
                    scene=scene,
                    guard_kind=guard_kind,
                    coc_text=coc_choices[coc_template_index],
                    guard_text=guard_choices[template_index],
                    target=target_for(scene, guard_kind),
                    split=split,
                )
            )
    return examples


def shuffled_guard_control(examples: list[GuardExample], seed: int) -> list[GuardExample]:
    """Swap guard families within each scene while preserving all other data."""
    if len(examples) < len(GUARD_KINDS) or len(examples) % len(GUARD_KINDS) != 0:
        raise ValueError("examples must contain complete three-guard scene groups")
    rng = np.random.default_rng(seed)
    result: list[GuardExample] = []
    width = len(GUARD_KINDS)
    for start in range(0, len(examples), width):
        group = examples[start : start + width]
        if len({example.scene.scene_id for example in group}) != 1:
            raise ValueError("guard examples are not grouped by scene")
        if tuple(example.guard_kind for example in group) != GUARD_KINDS:
            raise ValueError("each scene group must use the canonical guard order")
        # Alternate the two non-identity rotations so there is no learnable fixed inverse map.
        shift = int(rng.integers(1, width))
        texts = [example.guard_text for example in group]
        rotated = texts[shift:] + texts[:shift]
        result.extend(
            replace(example, guard_text=guard_text)
            for example, guard_text in zip(group, rotated, strict=True)
        )
    return result


def render_scene(scene: GuardScene, size: int = 224) -> Image.Image:
    if size < 160:
        raise ValueError("size must be at least 160")
    rng = np.random.default_rng(scene.visual_seed)
    image = Image.new("RGB", (size, size), (187, 194, 180))
    draw = ImageDraw.Draw(image)
    road = (67, 71, 74)
    lane = (225, 220, 173)
    crosswalk = (226, 226, 222)
    center = size // 2
    road_width = int(size * 0.52)
    half = road_width // 2
    draw.rectangle((center - half, 0, center + half, size), fill=road)
    draw.rectangle((0, center - half, size, center + half), fill=road)
    draw.line((center, 0, center, center - half), fill=lane, width=2)
    draw.line((center, center + half, center, size), fill=lane, width=2)
    draw.line((0, center, center - half, center), fill=lane, width=2)
    draw.line((center + half, center, size, center), fill=lane, width=2)

    # Stop line and zebra crossing ahead of ego.
    stop_y = center + half - int(size * 0.08)
    draw.line((center - half, stop_y, center + half, stop_y), fill=(245, 245, 245), width=4)
    stripe_w = max(3, size // 34)
    for x in range(center - half + 4, center + half - stripe_w, stripe_w * 2):
        draw.rectangle((x, center + half - 4, x + stripe_w, center + half + 5), fill=crosswalk)

    # Ego vehicle approaches upward from the bottom.
    ego_w, ego_h = int(size * 0.09), int(size * 0.16)
    ego_x = center + int(rng.integers(-3, 4))
    ego_y = size - int(size * 0.16)
    draw.rounded_rectangle(
        (ego_x - ego_w // 2, ego_y - ego_h // 2, ego_x + ego_w // 2, ego_y + ego_h // 2),
        radius=4,
        fill=(45, 119, 218),
        outline=(12, 40, 85),
        width=2,
    )

    # Cross traffic is either inside the conflict zone or visibly waiting outside it.
    car_w, car_h = int(size * 0.17), int(size * 0.085)
    cross_x = center if scene.cross_traffic_active else size - int(size * 0.09)
    cross_y = center + int(rng.integers(-4, 5))
    draw.rounded_rectangle(
        (cross_x - car_w // 2, cross_y - car_h // 2, cross_x + car_w // 2, cross_y + car_h // 2),
        radius=4,
        fill=(238, 139, 49),
        outline=(98, 48, 8),
        width=2,
    )

    # Pedestrian is either in the crosswalk or waiting on the right sidewalk.
    ped_x = center - int(size * 0.13) if scene.pedestrian_active else center + half + int(size * 0.08)
    ped_y = center + half + int(size * 0.01)
    head_r = max(3, size // 40)
    draw.ellipse((ped_x - head_r, ped_y - 13 - head_r, ped_x + head_r, ped_y - 13 + head_r), fill=(242, 211, 170), outline=(30, 30, 30))
    draw.line((ped_x, ped_y - 8, ped_x, ped_y + 8), fill=(120, 36, 142), width=4)
    draw.line((ped_x, ped_y, ped_x - 7, ped_y + 13), fill=(25, 25, 25), width=3)
    draw.line((ped_x, ped_y, ped_x + 7, ped_y + 13), fill=(25, 25, 25), width=3)

    # Traffic signal facing ego.
    signal_x = center + half + int(size * 0.06)
    signal_y = center + half - int(size * 0.10)
    box_w, box_h = int(size * 0.065), int(size * 0.13)
    draw.rounded_rectangle(
        (signal_x - box_w // 2, signal_y - box_h // 2, signal_x + box_w // 2, signal_y + box_h // 2),
        radius=3,
        fill=(25, 27, 28),
    )
    red_fill = (245, 45, 42) if scene.red_light else (67, 30, 28)
    green_fill = (30, 72, 36) if scene.red_light else (36, 220, 80)
    light_r = max(3, size // 48)
    draw.ellipse((signal_x - light_r, signal_y - 10 - light_r, signal_x + light_r, signal_y - 10 + light_r), fill=red_fill)
    draw.ellipse((signal_x - light_r, signal_y + 10 - light_r, signal_x + light_r, signal_y + 10 + light_r), fill=green_fill)
    return image


def prompt_for(example: GuardExample, mode: str) -> str:
    valid_modes = {
        "GENERIC_COC",
        "GENERIC_COC_GUARD",
        "TRADITIONAL_COC",
        "TRADITIONAL_COC_GUARD",
    }
    if mode not in valid_modes:
        raise ValueError(f"unknown prompt mode: {mode}")
    coc = example.coc_text if mode.startswith("TRADITIONAL") else REQUIREMENT_COC
    fields = [f"Requirement CoC: {coc}"]
    if mode.endswith("_GUARD"):
        fields.append(f"Safety guard: {example.guard_text}")
    fields.append(
        "Choose the next trajectory prototype from STOP or PROCEED. Answer with exactly one word."
    )
    return "\n".join(fields)
