#!/usr/bin/env python3
"""Train Qwen3-VL on temporal STOP-HOLD-RELEASE-GO contracts."""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch
from peft import LoraConfig, TaskType, get_peft_model
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader, Dataset
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

from .temporal_guard_world import (
    TemporalExample,
    generate_temporal_examples,
    prompt_for,
    render_storyboard,
    shuffled_guard_control,
)
from .train_qwen_guard_lora import language_attention_targets, seed_all, to_device


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--condition", choices=("COC_ONLY", "RICH_COC", "NATURAL_GUARD", "SHUFFLED_GUARD", "LOGIC_GUARD"), required=True)
    parser.add_argument("--model-id", default="Qwen/Qwen3-VL-2B-Instruct")
    parser.add_argument("--train-scenes", type=int, default=192)
    parser.add_argument("--validation-scenes", type=int, default=24)
    parser.add_argument("--test-scenes", type=int, default=48)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--gradient-accumulation", type=int, default=8)
    parser.add_argument("--learning-rate", type=float, default=2e-4)
    parser.add_argument("--lora-rank", type=int, default=8)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--max-eval-examples", type=int, default=96)
    return parser.parse_args()


class TemporalDataset(Dataset[TemporalExample]):
    def __init__(self, examples: list[TemporalExample]):
        self.examples = examples

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, index: int) -> TemporalExample:
        return self.examples[index]


class TemporalCollator:
    def __init__(self, processor: Any, mode: str):
        self.processor = processor
        self.mode = mode
        self.pad_id = int(processor.tokenizer.pad_token_id)

    @staticmethod
    def user_message(example: TemporalExample, mode: str) -> dict[str, Any]:
        return {"role": "user", "content": [
            {"type": "image", "image": render_storyboard(example.scene)},
            {"type": "text", "text": prompt_for(example, mode)},
        ]}

    def _encode(self, example: TemporalExample) -> dict[str, torch.Tensor]:
        user = self.user_message(example, self.mode)
        prompt = self.processor.apply_chat_template([user], tokenize=True, add_generation_prompt=True, return_dict=True, return_tensors="pt")
        full = self.processor.apply_chat_template(
            [user, {"role": "assistant", "content": [{"type": "text", "text": example.target}]}],
            tokenize=True, add_generation_prompt=False, return_dict=True, return_tensors="pt",
        )
        labels = full["input_ids"][0].clone()
        labels[: prompt["input_ids"].shape[1]] = -100
        return {"input_ids": full["input_ids"][0], "attention_mask": full["attention_mask"][0], "labels": labels,
                "pixel_values": full["pixel_values"], "image_grid_thw": full["image_grid_thw"]}

    def __call__(self, examples: list[TemporalExample]) -> dict[str, torch.Tensor]:
        encoded = [self._encode(e) for e in examples]
        return {
            "input_ids": pad_sequence([e["input_ids"] for e in encoded], batch_first=True, padding_value=self.pad_id),
            "attention_mask": pad_sequence([e["attention_mask"] for e in encoded], batch_first=True, padding_value=0),
            "labels": pad_sequence([e["labels"] for e in encoded], batch_first=True, padding_value=-100),
            "pixel_values": torch.cat([e["pixel_values"] for e in encoded]),
            "image_grid_thw": torch.cat([e["image_grid_thw"] for e in encoded]),
        }


def parse_choice(text: str) -> str:
    match = re.search(r"(?:^|\W)([ABCD])(?:$|\W)", text.strip().upper())
    return match.group(1) if match else "INVALID"


def generate_choice(model: Any, processor: Any, example: TemporalExample, mode: str, device: str) -> tuple[str, str]:
    user = TemporalCollator.user_message(example, mode)
    encoded = processor.apply_chat_template([user], tokenize=True, add_generation_prompt=True, return_dict=True, return_tensors="pt")
    encoded = to_device(dict(encoded), device)
    prompt_length = encoded["input_ids"].shape[1]
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        output = model.generate(**encoded, do_sample=False, max_new_tokens=12, use_cache=True, pad_token_id=processor.tokenizer.pad_token_id)
    raw = processor.tokenizer.decode(output[0, prompt_length:], skip_special_tokens=True).strip()
    return parse_choice(raw), raw


def evaluate(model: Any, processor: Any, examples: list[TemporalExample], mode: str, device: str, limit: int) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    model.eval()
    for example in examples[:limit]:
        prediction, raw = generate_choice(model, processor, example, mode, device)
        candidate = next((c for c in example.scene.candidates if c.label == prediction), None)
        required_entry = example.scene.clear_time + example.required_clear_duration
        violation = bool(candidate and candidate.entry_time is not None and candidate.entry_time + 1e-9 < required_entry)
        hold_violation = bool(candidate and candidate.role == "premature")
        deadlock = bool(candidate and candidate.role == "deadlock")
        goal_complete = bool(candidate and candidate.entry_time is not None)
        safe_progress = bool(candidate and not violation and goal_complete)
        rows.append({
            "scene_id": example.scene.scene_id, "contract_level": example.contract_level,
            "clear_time": example.scene.clear_time, "required_clear_duration": example.required_clear_duration,
            "target": example.target, "prediction": prediction, "raw": raw,
            "correct": prediction == example.target, "guard_violation": violation,
            "hold_violation": hold_violation, "deadlock": deadlock,
            "goal_complete": goal_complete, "safe_goal_complete": safe_progress,
        })
    by_level: dict[str, list[bool]] = defaultdict(list)
    for row in rows:
        by_level[row["contract_level"]].append(row["correct"])
    pairs: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        pairs[row["scene_id"]].append(row)
    complete_pairs = [pair for pair in pairs.values() if len(pair) == 2]
    n = len(rows)
    return {
        "example_count": n,
        "accuracy": sum(r["correct"] for r in rows) / n,
        "guard_violation_rate": sum(r["guard_violation"] for r in rows) / n,
        "hold_violation_rate": sum(r["hold_violation"] for r in rows) / n,
        "deadlock_rate": sum(r["deadlock"] for r in rows) / n,
        "goal_completion_rate": sum(r["goal_complete"] for r in rows) / n,
        "safe_goal_completion_rate": sum(r["safe_goal_complete"] for r in rows) / n,
        "contract_swap_pair_accuracy": sum(all(r["correct"] for r in pair) for pair in complete_pairs) / len(complete_pairs),
        "accuracy_by_contract_level": {k: sum(v) / len(v) for k, v in sorted(by_level.items())},
        "rows": rows,
    }


def train(model: Any, processor: Any, examples: list[TemporalExample], mode: str, args: argparse.Namespace) -> list[dict[str, float]]:
    loader = DataLoader(TemporalDataset(examples), batch_size=args.batch_size, shuffle=True,
                        generator=torch.Generator().manual_seed(args.seed + 1000), num_workers=0,
                        collate_fn=TemporalCollator(processor, mode))
    parameters = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(parameters, lr=args.learning_rate, weight_decay=0.01)
    optimizer.zero_grad(set_to_none=True)
    history: list[dict[str, float]] = []
    for epoch in range(args.epochs):
        model.train(); loss_sum = 0.0; count = 0; steps = 0
        for batch_index, batch in enumerate(loader):
            batch = to_device(batch, args.device)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                loss = model(**batch, use_cache=False).loss / args.gradient_accumulation
            loss.backward(); n = int(batch["input_ids"].shape[0]); count += n
            loss_sum += float(loss.detach()) * args.gradient_accumulation * n
            if (batch_index + 1) % args.gradient_accumulation == 0 or batch_index + 1 == len(loader):
                torch.nn.utils.clip_grad_norm_(parameters, 1.0); optimizer.step(); optimizer.zero_grad(set_to_none=True); steps += 1
        history.append({"epoch": epoch + 1, "mean_loss": loss_sum / count, "optimizer_steps": steps})
    return history


def main() -> int:
    args = parse_args()
    if not torch.cuda.is_available(): raise RuntimeError("CUDA is required")
    args.output_dir.mkdir(parents=True, exist_ok=False, mode=0o700); args.output_dir.chmod(0o700)
    seed_all(args.seed)
    mode = {"COC_ONLY": "COC_ONLY", "RICH_COC": "RICH_COC", "NATURAL_GUARD": "NATURAL_GUARD",
            "SHUFFLED_GUARD": "NATURAL_GUARD", "LOGIC_GUARD": "LOGIC_GUARD"}[args.condition]
    processor = AutoProcessor.from_pretrained(args.model_id); processor.tokenizer.padding_side = "right"
    model = Qwen3VLForConditionalGeneration.from_pretrained(args.model_id, dtype=torch.bfloat16, attn_implementation="sdpa").to(args.device)
    model.config.use_cache = False
    targets = language_attention_targets(model)
    model = get_peft_model(model, LoraConfig(r=args.lora_rank, lora_alpha=args.lora_rank * 2, lora_dropout=0.05,
                           bias="none", task_type=TaskType.CAUSAL_LM, target_modules=targets))
    model.enable_input_require_grads()
    training = generate_temporal_examples(args.train_scenes, args.seed, "train")
    if args.condition == "SHUFFLED_GUARD": training = shuffled_guard_control(training, args.seed + 77_777)
    validation = generate_temporal_examples(args.validation_scenes, args.seed, "validation")
    test = generate_temporal_examples(args.test_scenes, args.seed, "test")
    paraphrase = generate_temporal_examples(args.test_scenes, args.seed, "test_paraphrase")
    unseen = generate_temporal_examples(args.test_scenes, args.seed, "test_unseen")
    pre = evaluate(model, processor, validation, mode, args.device, args.max_eval_examples)
    history = train(model, processor, training, mode, args)
    result = {
        "experiment_id": "SMALL-VLM-TEMPORAL-GUARD-V0", "created_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "condition": args.condition, "prompt_mode": mode, "model_id": args.model_id, "seed": args.seed,
        "train_scenes": args.train_scenes, "train_examples": len(training), "epochs": args.epochs,
        "batch_size": args.batch_size, "gradient_accumulation": args.gradient_accumulation, "learning_rate": args.learning_rate,
        "pre_validation": pre, "history": history,
        "post_validation": evaluate(model, processor, validation, mode, args.device, args.max_eval_examples),
        "post_test": evaluate(model, processor, test, mode, args.device, args.max_eval_examples),
        "post_paraphrase": evaluate(model, processor, paraphrase, mode, args.device, args.max_eval_examples),
        "post_unseen": evaluate(model, processor, unseen, mode, args.device, args.max_eval_examples),
    }
    model.save_pretrained(args.output_dir / "adapter"); processor.save_pretrained(args.output_dir / "processor")
    (args.output_dir / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
